# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os
from sys import argv
from apis.imdb_api import imdb_user_lists
from modules.settings import get_theme
from modules.nav_utils import build_url, setView
# from modules.utils import logger

__addon_id__ = 'plugin.video.fen'
__addon__ = xbmcaddon.Addon(id=__addon_id__)
__handle__ = int(argv[1])
addon_dir = xbmc.translatePath(__addon__.getAddonInfo('path'))
icon_directory = get_theme()
default_imdb_icon = os.path.join(icon_directory, 'imdb.png')
fanart = os.path.join(addon_dir, 'fanart.png')

def imdb_build_user_lists(db_type):
    user_lists = imdb_user_lists(db_type)
    mode = 'build_movie_list' if db_type == 'movies' else 'build_tvshow_list'
    for item in user_lists:
        url_params = {'mode': mode, 'action': 'imdb_user_list_contents', 'list_id': item['list_id']}
        url = build_url(url_params)
        listitem = xbmcgui.ListItem(item['title'])
        listitem.setArt({'icon': default_imdb_icon, 'poster': default_imdb_icon, 'thumb': default_imdb_icon, 'fanart': fanart, 'banner': default_imdb_icon})
        xbmcplugin.addDirectoryItem(__handle__, url, listitem, isFolder=True)
    xbmcplugin.setContent(__handle__, 'files')
    xbmcplugin.endOfDirectory(__handle__)
    setView('view.main')




