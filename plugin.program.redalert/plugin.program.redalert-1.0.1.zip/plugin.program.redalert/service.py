import xbmc, xbmcaddon

AddonID = 'plugin.program.redalert'
Addon = xbmcaddon.Addon(AddonID)

if Addon.getSetting('isServiceActive') == 'true':
	xbmc.executebuiltin('XBMC.RunPlugin(plugin://plugin.program.redalert/?mode=0)')