import xbmc, xbmcaddon

AddonID = 'plugin.program.redalert'
Addon = xbmcaddon.Addon(AddonID)

if Addon.getSetting('isServiceActive') == 'true':
	xbmc.executebuiltin('RunPlugin(plugin://plugin.program.redalert/?mode=0)')