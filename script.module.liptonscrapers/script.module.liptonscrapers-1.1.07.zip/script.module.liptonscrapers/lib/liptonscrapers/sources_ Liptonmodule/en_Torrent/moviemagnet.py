# -*- coding: utf-8 -*-
############################################################################################################################################################################                                                                                                                                       #                                                                                                                                                                          #
#                                                                                                                                                                          #
#    ##     .   **       #########.  ########   #########   ##     ##    #########   #########   #########   #########   #########   ########   #########   ##########     #
#    ##         ##       ##     ##     ###      ##     ##   ###    ##    ##          ##          ##     ##   ##     ##   ##     ##   ##         ##     ##   ##             #
#    ##         ##       ##     ##     ###      ##     ##   ## #   ##    ##          ##          ##     ##   ##     ##   ##     ##   ##         ##     ##   ##             #
#    ##         ##       ########      ###      ##     ##   ##  #  ##    #########   ##          ########    #########   ## ######   ########   ########    ##########     #
#    ##         ##       ##            ###      ##     ##   ##   # ##           ##   ##          ##    ##    ##     ##   ##          ##         ##    ##            ##     #
#    ##         ##       ##            ###      ##     ##   ##    ###           ##   ##          ##     ##   ##     ##   ##          ##         ##     ##           ##     #
#    #######    ##       ##     .      ###      #########   ##     ##    #########   ##########  ##      #   ##     ##   ##          ########   ##      #   ##########     #
############################################################################################################################################################################
import re
import urllib
import urlparse
import json

from liptonscrapers.modules import cleantitle
from liptonscrapers.modules import client
from liptonscrapers.modules import debrid
from liptonscrapers.modules import source_utils


class source:
	def __init__(self):
		self.priority = 0
		self.language = ['en']
		self.domain = ['moviemagnet.unblockit.biz']
		self.base_link = 'https://moviemagnet.unblockit.biz'
		self.search_link = '/movies/search_movies?term=%s'


	def movie(self, imdb, title, localtitle, aliases, year):
		try:
			url = {'imdb': imdb, 'title': title, 'year': year}
			url = urllib.urlencode(url)
			return url
		except:
			return


	def sources(self, url, hostDict, hostprDict):
		sources = []
		try:
			if url is None:
				return sources

			if debrid.status() is False:
				return sources

			data = urlparse.parse_qs(url)
			data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

			title = data['title']
			year = data['year']

			query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', '', title)

			url = self.search_link % urllib.quote_plus(query)
			url = urlparse.urljoin(self.base_link, url)
			

			try:
				r = client.request(url)
				if r == str([]):
					return sources
				r = json.loads(r)

				id = ''
				for i in r:
					if i['original_title'] == title and i['release_date'] == year:
						id = i['id']
						break

				if id == '':
					return sources
				link = 'http://moviemagnet.co/movies/torrents?id=%s' % id
				result = client.request(link)
				if 'magnet' not in result:
					return sources

				result = re.sub(r'\n', '', result)
				links = re.findall(r'<tr>.*?<a title="Download:\s*(.+?)"href="(magnet:.+?)">.*?title="File Size">\s*(.+?)\s*</td>', result)

				for link in links:
					name = link[0]
					t = name.split(year)[0].replace(year, '').replace('(', '').replace(')', '').replace('&', 'and').replace('+', ' ')

					if cleantitle.get(t) != cleantitle.get(title):
						continue

					url = link[1]
					url = urllib.unquote(url).decode('utf8').replace('&amp;', '&')
					url = url.split('&tr')[0]

					if year not in name:
						continue

					quality, info = source_utils.get_release_quality(name, url)

					try:
						size = link[2]
						div = 1 if size.endswith(('GB', 'GiB')) else 1024
						size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
						size = '%.2f GB' % size
						info.insert(0, size)
					except:
						size = '0'
						pass

					info = ' | '.join(info)

					sources.append({'source': 'torrent', 'quality': quality, 'language': 'en', 'url': url,
														'info': info, 'direct': False, 'debridonly': True})
				return sources

			except:
				source_utils.scraper_error('MOVIEMAGNET')
				return sources

		except:
			source_utils.scraper_error('MOVIEMAGNET')
			return sources


	def resolve(self, url):
		return url
